package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Aliens;
import com.example.demo.repos.AlienRepo;






@RestController

public class AlienContoller {
	@Autowired
	AlienRepo repo;
	@RequestMapping("/")
	public ModelAndView homePage()
	
	{
		ModelAndView mvk=new ModelAndView ();
	String myname="     ";
	mvk.addObject("message", myname);
	mvk.setViewName("home.jsp");
		return mvk;
	}
	
	@RequestMapping("loginpage")
public ModelAndView loginpage(@RequestParam("username") String u , @RequestParam("password") String p)
{
		Aliens temp= new Aliens();
		temp=repo.findById(u).orElse(null);
		
		if(temp==null) {
			ModelAndView mv=new ModelAndView();
			mv.addObject("message", "Incorrect Username ");
			mv.setViewName("home.jsp");
			return mv;
		}
		if(temp.getPassword().equals(p)) {
			ModelAndView mv=new ModelAndView();
			mv.addObject("abj", temp);
			mv.setViewName("welcome.jsp");
			return mv;
		}
		else {
			ModelAndView mv=new ModelAndView();
			mv.addObject("message", "Incorrect password ");
			mv.setViewName("home.jsp");
			return mv;
			
		}
		

}
	@RequestMapping("signup")
	public ModelAndView signup(@RequestParam("username") String u, @RequestParam("password") String p, @RequestParam("employeecode") String e, @RequestParam("department") String d)                 
	{
		Aliens a2=new Aliens();
		a2.setUsername(u);
		a2.setPassword(p);
		a2.setEmployeeCode(e);
		a2.setDepartment(d);
		
		repo.save(a2);
		ModelAndView mv2=new ModelAndView();
		mv2.addObject("message","succesfully signedUp Now login ");
		mv2.setViewName("home.jsp");
		return mv2;
			}
	
	
	
}










