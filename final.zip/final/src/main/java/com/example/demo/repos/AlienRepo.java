package com.example.demo.repos;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Aliens;

public interface AlienRepo extends CrudRepository<Aliens, String> {

}
